<?php

namespace Kendo\Data;

class HierarchicalDataSourceSchema extends \Kendo\Data\DataSourceSchema {

//>> Properties
//<< Properties
}

?>

