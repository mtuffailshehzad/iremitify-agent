<?php
namespace Kendo\Data;

class PivotDataSourceTransportRead extends \Kendo\Data\DataSourceTransportRead {
//>> Properties

//<< Properties
}

?>
